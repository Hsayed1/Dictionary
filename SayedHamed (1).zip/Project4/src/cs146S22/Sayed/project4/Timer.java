package cs146S22.Sayed.project4;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
/**
 * This class is used to measure the time of various methods of the dictionary class. It prints out the time
 * @author sayed
 *
 */
public class Timer
{
	public static void main(String[] args) 
	{
		
		long start = System.currentTimeMillis();
		Dictionary tester = Reader.fillDictionary("src/cs146S22/Sayed/project4/sjsuDictionary.txt");
		long stop = System.currentTimeMillis();
		long time = stop - start;
		
		System.out.println("The amount of time to fill the dictionary: " + time);
		System.out.println("CurrentSize: " + tester.getcurrentSize() + "   Size: " + tester.getSize());
		System.out.println("Load factor: " + tester.getLoadFactor());
		
		start = System.currentTimeMillis();
		tester.insert("Hamed");
		stop = System.currentTimeMillis();
		time = stop - start;
		System.out.println("The amount of time to insert a new word: " + time);
		
		start = System.currentTimeMillis();
		tester.delete("Hamed");
		stop = System.currentTimeMillis();
		time = stop - start;
		System.out.println("The amount of time to delete a word: " + time);		
	}
}