package cs146S22.Sayed.project4;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
/**
 * This class is a file reader class with two static methods. One that reads the dictionary file 
 * and another that reads the poem file
 * @author sayed
 *
 */
public class Reader
{
	/**
	 * This method reads the dictionary file and stores the words into a dictionary object
	 * @param fileName the name of the file
	 * @return Dictionary a dictionary with all of the words
	 */
	public static Dictionary fillDictionary(String fileName)
	{
		Dictionary result = new Dictionary();
		try
		{
			File file = new File(fileName);
			FileReader fr = new FileReader(file);
			BufferedReader br = new BufferedReader(fr);
			String word = " ";
			while(word != null)
			{
				word = br.readLine();
				if(word != null)
					result.insert(word);
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return result;
	}
	
	/**
	 * This class reads the poem file and returns an array with the words of the poem
	 * @param fileName the name of the file
	 * @return String[] an array of the words in the poem
	 */
	public static String[] readPoem(String fileName)
	{
		String [] poem = null;
		try
		{
			File file = new File(fileName);
			FileReader fr = new FileReader(file);
			BufferedReader br = new BufferedReader(fr);
			String line = br.readLine();
			line = line.toLowerCase();
			line = line.replaceAll("\\p{Punct}", ""); //gets rid of punctuation
			poem = line.split(" ");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return poem;
	}
}
