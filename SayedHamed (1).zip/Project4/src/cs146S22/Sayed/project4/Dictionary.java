package cs146S22.Sayed.project4;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Arrays;
import java.util.List;

/**
 * This class represents a Hash Table (from scratch) to store n key-value pairs in a hash table of size m (> n)
 * The following hash table resolves collisions by finding empty entries in the table with linear probing. 
 * Basic operations are: Search (lookup), Insert, and Delete
 * @author sayed
 *
 */
public class Dictionary
{
	private HashNode []				table;
	private int 					size;
	private int						currentSize;

	private static final float UPPER_BOUND = (float) 0.8;
	private static final float LOWER_BOUND = (float) 0.5;
	
	/**
	 * Constructor for the class
	 * sets the initial size of the array to 37 and current size to 0
	*/
	public Dictionary()
	{
		size = 37;
		table = new HashNode[size];
		currentSize = 0;
	}
	
	/**
	 * The following method inserts a String into the array using linear probing.
	 * After insertion, if the load factor is exceeding .8 the array is resized
	 * 
	 * @param key the string to be inserted
	 */
	public void insert(String key)
	{
		HashNode node = new HashNode(key);
		int index = hash(key);
		if(table[index] == null)
		{
			table[index] = node;
			currentSize++;
		}
		else
		{
			while(table[index] != null)
			{
				index = (index + 1) % size; //linear probing
			}
			table[index] = node;
			currentSize++;
		}
		reSizeLarger();  //check if needs to be resized
	}
	
	/**
	 * This method deletes the specified string from the array.
	 * After deletion, if the load factor is less than .6, the array is resized
	 * @param key
	 * @return boolean true if key was deleted, false if key was not found
	 */
	public boolean delete(String key)
	{
		int index = hash(key);
        while (table[index] != null)
        {
            if (table[index].getKey().equals(key))   //key is in table
            {
            	table[index] = null; //removal
            	currentSize--;
            	reSizeSmaller();
            	return true;
            }
            index = (index + 1) % size;
        }
		return false;
	}
	
	/**
	 * This method looks up if the specified key is in the array
	 * @param key the string to be looked up
	 * @return String the string if found, otherwise null
	 */
	public String lookUp(String key)
	{
		int index = hash(key);
        while (table[index] != null)
        {
            if (table[index].getKey().equals(key))
                return table[index].getValue();
            index = (index + 1) % size;
        }            
        return null;            
	}
	
	/**
	 * This method is used to make the hashtable bigger if the condition is met
	 */
	private void reSizeLarger()
	{
	
		if(getLoadFactor() >= UPPER_BOUND)
		{
			//find the next prime number
			int newSize = size;
			int counter = -1;
			while(counter != 0)
			{
				newSize++;
				counter = 0;
				for (int i = 2; i < newSize / 2; i++)
				{
					if (newSize % i == 0)
					{
						counter++;
					}
				}
			}
			
			//After prime number is found, move elements into arraylist and rehash
			List<HashNode> list = Arrays.asList(table);	
			size = newSize;
			table = new HashNode[newSize];
			for(int i = 0; i < list.size(); i++)
			{
				HashNode n = list.get(i);
				if (n != null)
				{
					int newIndex = hash(n.getKey());		
					if(table[newIndex] == null)
						table[newIndex] = n;
					else
					{
						while(table[newIndex] != null)
						{
							 newIndex = (newIndex + 1) % newSize; 
						}
						table[newIndex] = n;
					}
				}
			}
			
		}
	}
	
	/**
	 * This method is used to make the array smaller if the condition is met
	 */
	public void reSizeSmaller()
	{
		if(getLoadFactor() < LOWER_BOUND)
		{
			//Find first prime number
			int counter = -1;
			int newSize = size;
			while(counter != 0)
			{
				newSize--;
				counter = 0;
				for (int i = 2; i < newSize / 2; i++)
				{
					if (newSize % i == 0)
					{
						counter++;
					}
				}
			}
			
			//After prime number is found, rehash the array
			List<HashNode> list = Arrays.asList(table);
			size = newSize;
			table = new HashNode[newSize];
			for(int i = 0; i < list.size(); i++)
			{
				HashNode n = list.get(i);
				if (n != null)
				{
					int newIndex = hash(n.getKey());
					if(table[newIndex] == null)
						table[newIndex] = n;
					else
					{
						while(table[newIndex] != null)
						{
							 newIndex = (newIndex + 1) % newSize; 
						}
						table[newIndex] = n;
					}
				}
			}
		}
	}
	
	/**
	 * This method returns the index based on the key provided after it is put through the hash function
	 * @param key the string
	 * @return int the index
	 */
	private int hash(String key)
	{
		return (key.hashCode() & 0x7fffffff) % size;
	}
	
	/**
	 * This method returns the load factor of the array
	 * @return float the load factor
	 */
	public float getLoadFactor()
	{
		return (float)currentSize / (float)size;
	}
	
	/**
	 * This method returns the current size
	 * @return int current size
	 */
	public int getcurrentSize()
	{
		return currentSize;
	}
	
	/**
	 * this method returns the size
	 * @return int size
	 */
	public int getSize()
	{
		return size;
	}	
}