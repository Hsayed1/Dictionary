package cs146S22.Sayed.project4;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Before;
import org.junit.jupiter.api.Test;
/**
 * This class contains the test cases for methods of the dictionary class
 * @author sayed
 *
 */
class Tester
{
	Dictionary 		tester;
	String[] 		poem;
	
	@Test
	public void testInsert()
	{
		tester = Reader.fillDictionary("src/cs146S22/Sayed/project4/sjsuDictionary.txt");
		tester.insert("CS146");
		assertNotNull(tester.lookUp("CS146"));
	}
	
	@Test
	public void testDelete()
	{
		tester = Reader.fillDictionary("src/cs146S22/Sayed/project4/sjsuDictionary.txt");
		assertTrue(tester.delete("ababa"));
		assertFalse(tester.delete("Hamed"));
	}
	
	@Test
	public void testLookUp()
	{
		poem = Reader.readPoem("src/cs146S22/Sayed/project4/poem.txt");
		tester = Reader.fillDictionary("src/cs146S22/Sayed/project4/sjsuDictionary.txt");
		long start, stop, time, avgTime = 0;
		for(int i = 0; i < poem.length; i++)
		{
			start = System.currentTimeMillis();
			assertNotNull(tester.lookUp(poem[i]));
			stop = System.currentTimeMillis();
			time = stop - start;
			
			avgTime = avgTime + time;
		}
		
		avgTime = avgTime / (long)poem.length;
		
		System.out.println("The average lookup time for the poem: " + avgTime);
	}
}