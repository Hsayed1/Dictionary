package cs146S22.Sayed.project4;
/**
 * This class creates a key-value object used to store in dictionary class
 * @author sayed
 *
 */
public class HashNode
{
	private String 			key;
	private String 			value;
	
	/**
	 * Constructs a Hash Node and initializes the key and the value
	 * @param value a string
	 */
	public HashNode(String value)
	{
		this.key = value;
		this.value = value;
	}
	
	/**
	 * returns the key
	 * @return String the key
	 */
	public String getKey()
	{
		return key;
	}
	
	/**
	 * returns the value
	 * @return String the value
	 */
	public String getValue()
	{
		return value;
	}
}
